import LinkedList from './LinkedList.mjs';

export default class Graph {
    #matrizAdyacencia = [];
    #map = new Map();

    constructor() {}

    agregarVertice(...vertices) {
        for (let value of vertices) {
            this.#matrizAdyacencia.push(new LinkedList());
            this.#map.set(value, this.#matrizAdyacencia.length - 1);
        }
    }

    agregarVerticeIndividual(value) {
        this.#matrizAdyacencia.push(new LinkedList());
        this.#map.set(value, this.#matrizAdyacencia.length - 1);
    }

    agregarConexion(start, end, weight = 1) {
        if (this.#map.has(start) && this.#map.has(end)) {
            this.#matrizAdyacencia[this.#map.get(start)].push(end, weight);
            return true;
        }
        return false;
    }

    recorridoAnchura(callback){
        let queue = []
        let list = []
        const entries = [...structuredClone(this.#map)];
        for (let i=0; i<this.#matrizAdyacencia.length;i++)
            list[i] = false
        
        let [key] = entries[0]
        queue.push(key)
        
        while (queue.length > 0) {
            let val = queue.shift() 
            callback(val) 
            list[this.#map.get(val)] = true 
            for (let i=0;i<this.#matrizAdyacencia[this.#map.get(val)].length;i++) {
                if (this.#matrizAdyacencia[this.#map.get(val)][i]){
                    let [key] = entries[i]
                    if (!list[this.#map.get(key)] && !queue.includes(key)) 
                        queue.push(key) 
                }
            }
        }

    }

    recorridoProfundidadRecursiva(callback, startNode = null) {
        let visited = new Array(this.#matrizAdyacencia.length).fill(false);
    
        const dfs = (node) => {
            if (!visited[this.#map.get(node)]) {
                callback(node);
                visited[this.#map.get(node)] = true;
                let neighbors = [...this.#matrizAdyacencia[this.#map.get(node)].iterator()];
                for (let neighbor of neighbors) {
                    dfs(neighbor.name);
                }
            }
        };
    
        if (startNode === null) {
            for (let [key] of this.#map) {
                dfs(key);
            }
        } else {
            dfs(startNode);
        }
    }

    // Implementación del algoritmo de Dijkstra
    dijkstra(start) {
        let distances = new Map();
        let previousVertices = new Map();
        let visited = new Set();
        let priorityQueue = new MinPriorityQueue(); // Debes implementar o importar una cola de prioridad mínima
        
        // Inicializar las distancias y la cola de prioridad
        this.#map.forEach((_, vertex) => {
            if (vertex === start) {
                distances.set(vertex, 0);
                priorityQueue.enqueue(vertex, 0);
            } else {
                distances.set(vertex, Infinity);
                priorityQueue.enqueue(vertex, Infinity);
            }
            previousVertices.set(vertex, null);
        });
        
        while (!priorityQueue.isEmpty()) {
            let { element: currentVertex } = priorityQueue.dequeue();
            visited.add(currentVertex);
            
            let neighbors = [...this.#matrizAdyacencia[this.#map.get(currentVertex)].iterator()];
            for (let { name: neighbor, distance: weight } of neighbors) {
                if (!visited.has(neighbor)) {
                    let newDist = distances.get(currentVertex) + weight;
                    if (newDist < distances.get(neighbor)) {
                        distances.set(neighbor, newDist);
                        previousVertices.set(neighbor, currentVertex);
                        priorityQueue.enqueue(neighbor, newDist);
                    }
                }
            }
        }
        
        return { distances, previousVertices };
    }
}

// Implementación de una cola de prioridad mínima
class MinPriorityQueue {
    constructor() {
        this.heap = [];
    }
    
    isEmpty() {
        return this.heap.length === 0;
    }
    
    enqueue(element, priority) {
        this.heap.push({ element, priority });
        this._bubbleUp();
    }
    
    dequeue() {
        if (this.isEmpty()) return null;
        if (this.heap.length === 1) return this.heap.pop();
        
        const min = this.heap[0];
        this.heap[0] = this.heap.pop();
        this._bubbleDown();
        
        return min;
    }
    
    _bubbleUp() {
        let index = this.heap.length - 1;
        while (index > 0) {
            let element = this.heap[index];
            let parentIndex = Math.floor((index - 1) / 2);
            let parent = this.heap[parentIndex];
            
            if (parent.priority <= element.priority) break;
            
            this.heap[index] = parent;
            this.heap[parentIndex] = element;
            index = parentIndex;
        }
    }
    
    _bubbleDown() {
        let index = 0;
        const length = this.heap.length;
        const element = this.heap[0];
        
        while (true) {
            let leftChildIndex = 2 * index + 1;
            let rightChildIndex = 2 * index + 2;
            let leftChild, rightChild;
            let swapIndex = null;
            
            if (leftChildIndex < length) {
                leftChild = this.heap[leftChildIndex];
                if (leftChild.priority < element.priority) {
                    swapIndex = leftChildIndex;
                }
            }
            
            if (rightChildIndex < length) {
                rightChild = this.heap[rightChildIndex];
                if (
                    (swapIndex === null && rightChild.priority < element.priority) ||
                    (swapIndex !== null && rightChild.priority < leftChild.priority)
                ) {
                    swapIndex = rightChildIndex;
                }
            }
            
            if (swapIndex === null) break;
            
            this.heap[index] = this.heap[swapIndex];
            this.heap[swapIndex] = element;
            index = swapIndex;
        }
    }
}
