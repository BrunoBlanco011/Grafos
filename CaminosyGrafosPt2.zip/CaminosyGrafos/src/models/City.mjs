export default class City {
    constructor(name, distance) {
        this.name = name;
        this.distance = distance;
    }
}
