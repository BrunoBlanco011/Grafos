import Graph from "../models/Graph.mjs"; 

document.addEventListener('DOMContentLoaded', function() {
    const grafo = new Graph(); 
    
    const formAgregarVertice = document.getElementById('addVertexForm');
    formAgregarVertice.addEventListener('submit', function(event) {
        event.preventDefault(); 

        const inputNombreVertice = document.getElementById('vertexName');
        const nombreVertice = inputNombreVertice.value.trim();

        if (nombreVertice !== '') {
            grafo.agregarVertice(nombreVertice);
            console.log(`Vértice agregado: ${nombreVertice}`);
            inputNombreVertice.value = ''; 
        } else {
            console.log('Ingrese un nombre válido para el vértice.');
        }
    });

    const formAgregarArista = document.getElementById('addEdgeForm');
    formAgregarArista.addEventListener('submit', function(event) {
        event.preventDefault();

        const inputVerticeInicial = document.getElementById('startVertex');
        const inputVerticeFinal = document.getElementById('endVertex');
        const inputPeso = document.getElementById('weight');

        const verticeInicial = inputVerticeInicial.value.trim();
        const verticeFinal = inputVerticeFinal.value.trim();
        const peso = parseInt(inputPeso.value);

        if (verticeInicial !== '' && verticeFinal !== '' && !isNaN(peso)) {
            const agregado = grafo.agregarConexion(verticeInicial, verticeFinal, peso);
            if (agregado) {
                console.log(`Arista agregada de ${verticeInicial} a ${verticeFinal} con peso ${peso}`);
                inputVerticeInicial.value = '';
                inputVerticeFinal.value = '';
                inputPeso.value = '';
            } else {
                console.log('No se pudo agregar la arista.');
            }
        } else {
            console.log('Ingrese valores válidos para los vértices y el peso.');
        }
    });

    const botonDFS = document.getElementById('dfsBtn');
    botonDFS.addEventListener('click', function() {
        const contenedorResultados = document.getElementById('resultContainer');
        contenedorResultados.innerHTML = ''; 
        grafo.recorridoProfundidadRecursiva((vertice) => {
            console.log(`Visitando el vértice: ${vertice}`);
            contenedorResultados.innerHTML += `${vertice} `;
        });
    });

    // Agregar funcionalidad de Dijkstra
    const formDijkstra = document.getElementById('dijkstraForm');
    formDijkstra.addEventListener('submit', function(event) {
        event.preventDefault();

        const inputVerticeInicio = document.getElementById('startDijkstraVertex');
        const verticeInicio = inputVerticeInicio.value.trim();

        if (verticeInicio !== '') {
            const { distances, previousVertices } = grafo.dijkstra(verticeInicio);
            const contenedorResultados = document.getElementById('dijkstraResultContainer');
            contenedorResultados.innerHTML = ''; 

            distances.forEach((distance, vertex) => {
                contenedorResultados.innerHTML += `Distancia desde ${verticeInicio} hasta ${vertex}: ${distance}<br>`;
            });

            console.log(`Distancias desde el vértice ${verticeInicio}:`);
            console.log(distances);
            console.log('Vertices anteriores:', previousVertices);
        } else {
            console.log('Ingrese un vértice de inicio válido para Dijkstra.');
        }
    });

});
